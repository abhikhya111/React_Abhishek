import React from 'react'
import Header from '../Header'

export default function OurServices() {
  return (
    <div>
        <Header/>
        OurServices
    </div>
  )
}
